## Copyright (C) 2017 priyank_agrawal
## 
## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} tmp (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: priyank_agrawal <priyank_agrawal@PRIYANK-PC>
## Created: 2017-06-26
X1=X2=rand(118,1);
degree = 5;
out = ones(size(X1(:,1)));
for i = 1:degree
    for j = 0:i
        %out(:, end+1) = (X1.^(i-j)).*(X2.^j);
        str1='X1.^';
        str2=int2str(i-j);
        str3='* X2^';
        str4=int2str(j);
        t1=strcat(str1,str2);
        t2=strcat(str3,str4);
        t3=strcat(t1,t2);
        disp(t3);
    end
    disp('');
end